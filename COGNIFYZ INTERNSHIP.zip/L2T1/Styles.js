function showAlert() {
    alert("Button clicked! This is a Bulma card component.");
  }
  